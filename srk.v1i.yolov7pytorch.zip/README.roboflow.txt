
srk - v1 2022-11-20 1:18am
==============================

This dataset was exported via roboflow.com on November 19, 2022 at 7:49 PM GMT

Roboflow is an end-to-end computer vision platform that helps you
* collaborate with your team on computer vision projects
* collect & organize images
* understand unstructured image data
* annotate, and create datasets
* export, train, and deploy computer vision models
* use active learning to improve your dataset over time

It includes 94 images.
Srk are annotated in YOLO v7 PyTorch format.

The following pre-processing was applied to each image:
* Resize to 640x640 (Stretch)

No image augmentation techniques were applied.


