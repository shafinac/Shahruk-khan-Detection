# srk > 2022-11-20 1:18am
https://universe.roboflow.com/object-detection/srk-wo0mp

Provided by a Roboflow user
License: CC BY 4.0

